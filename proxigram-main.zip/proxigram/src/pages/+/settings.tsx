import { Layout } from "@/components/layouts/Layout";

export default function Settings() {
	return (
		<Layout
			meta={{
				title: "Settings",
				description:
					"Customise your experience with Proxigram, the private frontend for Instagram",
			}}
		>
			<h2>Page under construction</h2>
		</Layout>
	);
}
