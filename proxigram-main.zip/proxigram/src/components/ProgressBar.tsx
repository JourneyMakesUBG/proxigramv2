import styles from "@/styles/progress-bar.module.css";

const ProgressBar = () => {
	return <span className={styles.progress} />;
};
export default ProgressBar;
